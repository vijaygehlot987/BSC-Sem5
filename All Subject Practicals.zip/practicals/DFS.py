graph={
    "S" : ["A", "B", "C"],
    "A" : ["B", "D", "S"],
    "B" : ["A", "S", "D", "H"],
    "C" : ["S", "L"],
    "D" : ["A", "F", "B"],
    "E" : ["G", "K"],
    "F" : ["D", "H"],
    "G" : ["H", "E"],
    "H" : ["B", "F", "G"],
    "I" : ["L", "K"],
    "J" : ["L", "K"],
    "K" : ["I", "J", "E"],
    "L" : ["C", "I", "J"]
    }
def DFS(graph,src,des,tree):
    if src not in tree:
        
        if src==des or src!=des:
            tree.append(src)
            for i in graph[src]:
                if des not in tree:
                    DFS(graph,i,des,tree)
    return tree

a='E'
b='K'
tree=DFS(graph,a,b,[])
print(tree)
