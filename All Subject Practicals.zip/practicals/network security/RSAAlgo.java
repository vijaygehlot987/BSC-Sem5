package rsaalgo;

import java.security.*;
import java.math.*;
import java.util.*;

public class RSAAlgo {
    
    public static void main(String[] args) {
        String plnText,pad,cphText;
	int rnd;
	byte[] b = new byte[20];//   Constructs a newly allocated Byte object that represents the specified byte value.
	BigInteger p,q,n,e,d,m;
	plnText = "Welcome to the world of cryptography";
	SecureRandom random = new SecureRandom();
	random.nextBytes(b);//Generates a user-specified number of random bytes.
	p = new BigInteger(5,100,random);//Constructs a randomly generated positive BigInteger that is probably prime, with the specified bitLength.
        //public BigInteger(int bitLength, int certainty, Random rnd)

	System.out.println("P="+p);
	q = new BigInteger(5,100,random);
	System.out.println("Q="+q);
	n = p.multiply(q);
	System.out.println("N=P*Q="+n);
	e = new BigInteger("3");
	m = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
	System.out.println("(P-1)*(Q-1)="+m);		
	while(m.gcd(e).intValue()!=1)  //Returns a BigInteger whose value is the greatest common divisor of abs(m) and abs(e).
	{
            System.out.println(m.gcd(e).intValue());
            e = e.add(new BigInteger("2"));
            System.out.println("e="+e);
	}
	d = e.modInverse(m); //Returns a BigInteger whose value is (e-1 mod m).
	System.out.println("d="+d);
        
	RSAAlgo r = new RSAAlgo();
	cphText = r.RSAEN(plnText,e.intValue(),n);
	System.out.println("Cipher Text: "+cphText);
	plnText = r.RSADE(cphText,d.intValue(),n);
	System.out.println("Plain Text: "+plnText);
    }
    
    public String RSAEN(String plnText,int e, BigInteger n)
    {
	String cphText;
	int c1,c2,result;
	String str;
	cphText="";
	for(int i=0;i<plnText.length();i++)
	{
            c1 = (int)plnText.charAt(i);//Gives Character at specified position.
            str = ""+c1; //convert into string
            BigInteger big = new BigInteger(str);//Translates the decimal String representation of a BigInteger into a BigInteger. 
            BigInteger cph = big.pow(e).mod(n);
            cphText = cphText + (char)cph.intValue();   //intvalue() converts Biginteger into integer.
	}		
	return cphText;
    }
    
    public String RSADE(String cphText,int d, BigInteger n)
    {
	String plnText;
	int c1,c2,result;
	String str;
	plnText="";
	for(int i=0;i<cphText.length();i++)
	{
            c1 = (int)cphText.charAt(i);
            str = ""+c1;
            BigInteger big = new BigInteger(str);
            BigInteger pln = big.pow(d).mod(n);
            plnText = plnText + (char)pln.intValue();
	}		
	return plnText;
    }
    
}
