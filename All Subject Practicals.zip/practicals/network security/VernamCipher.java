package vernam.cipher;

import java.util.Scanner;

public class VernamCipher {
    public static void main(String[] args) {
        char alpha[]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        System.out.println("Enter your plain text");
        Scanner sc=new Scanner(System.in);
        String txt=sc.nextLine();
        txt=txt.replaceAll("\\s+","");
        int txtlen=txt.length();
        int[] textindex=new int[txtlen];
        int[] keyindex=new int[txtlen];
        int[] addindex=new int[txtlen];
        char[] ciphertxt=new char[txtlen];
        System.out.println("Enter your key");
        String key=sc.nextLine();
        char[] arrtxt=txt.toCharArray();
        char[] arrkey=key.toCharArray();
        System.out.print(arrtxt);
        for(int i=0;i<addindex.length;i++){
            addindex[i]=-1;
        }
        for(int i=0;i<arrtxt.length;i++)
        {
            for(int j=0;j<alpha.length;j++){
                if(arrtxt[i]==alpha[j]){
                    textindex[i]=j;
                    System.out.print(textindex[i]+" ");
                    break;
                }
            }
        }
        System.out.println();
        for(int i=0;i<arrkey.length;i++)
        {
            for(int j=0;j<alpha.length;j++){
                if(arrkey[i]==alpha[j]){
                    keyindex[i]=j;
                    System.out.print(keyindex[i]+" ");
                    break;
                }
            }
        }
        System.out.println();
        for(int i=0;i<txtlen;i++){
            addindex[i]=textindex[i]+keyindex[i];
            System.out.print(addindex[i]+" ");
        }
        System.out.println();
        for(int i=0;i<addindex.length;i++){
            if(addindex[i]>25){
                addindex[i]=addindex[i]-26;
            }
        }
        for(int i=0;i<addindex.length;i++){
            for(int j=0;j<alpha.length;j++){
                if(addindex[i]==j){
                    ciphertxt[i]=alpha[j];
                    System.out.print(ciphertxt[i]);
                    break;
                }
            }
        }
    }
    
}
