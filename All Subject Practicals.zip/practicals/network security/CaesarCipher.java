package caesar.cipher;
import java.util.*;
public class CaesarCipher {

    public static void main(String[] args) {
        String inp;
        char[] newcipher=new char[50];
        char letters[]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string to convert to caesar cipher");
        inp=sc.nextLine();
        int len=inp.length();
        for(int i=0;i<len;i++){
            char cipher = inp.charAt(i);
            int letlen=letters.length;
            for(int j=0;j<letlen;j++){
                if(cipher=='X'){
                    newcipher[i]='A';
                }
                
                else if(cipher=='Y'){
                    newcipher[i]='B';
                }
                
                else if(cipher=='Z'){
                    newcipher[i]='C';
                }
                
                else if(letters[j]==cipher){
                    j+=2;
                    newcipher[i]=letters[j];
                }
            }
        }
        System.out.println(newcipher);
    }
}
