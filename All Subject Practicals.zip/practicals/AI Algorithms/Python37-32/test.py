import math
import sys
graph={'A': ['B'=2,'C'=5,'D'=6],
    'B': ['A'=2, 'C'=3, 'D'=4,'E'=8],
    'C': ['A'=5.'B'=3],
    'D': ['E'=4, 'A'=6,'B'=4],
    'E': ['B'=8]}
print(graph)
    
    
