import hashlib 
  
# initializing string
str=input("enter a string")
  
# encoding GeeksforGeeks using encode() 
# then sending to md5() 
result = hashlib.md5(str.encode()) 
  
# printing the equivalent hexadecimal value. 
print("Thedecimal equivalent of hash is : ", end ="") 
print(result.digest()) 
