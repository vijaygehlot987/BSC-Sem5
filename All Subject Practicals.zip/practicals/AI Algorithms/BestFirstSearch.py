import heapq
def bestFirstSearch(graph, hueristic, start, end):
    p = [hueristic[start], start, start]
    processed = []
    done = []
    pq = [[hueristic[start], start, start]]
    while True :
        heapq.heapify(pq)
        print(pq)
        p = pq.pop(0)
        if p[1] == end:
            processed.append(p)
            break
        for node in graph[p[1]]:
            if node not in done:
                found = False
                for check in pq:
                    if check[1] == node:
                        found = True
                        break
                if not found:
                    pq.append([hueristic[node], node, p[1]])
        done.append(p[1])
        processed.append(p)
    print(processed)
    path = []
    trace = end
    for i in range(len(processed) - 1, -1, -1):
        if trace == processed[i][1]:
            path.insert(0, processed[i][1])
            trace = processed[i][2]
    return path
    

g = {"S" : ["A", "B", "C"],
     "A" : ["B", "D", "S"],
     "B" : ["A", "S", "D", "H"],
     "C" : ["S", "L"],
     "D" : ["A", "F", "B"],
     "E" : ["G", "K"],
     "F" : ["D", "H"],
     "G" : ["H", "E"],
     "H" : ["B", "F", "G"],
     "I" : ["L", "K"],
     "J" : ["L", "K"],
     "K" : ["I", "J", "E"],
     "L" : ["C", "I", "J"]
    }

h = {'S':10, 'A':9, 'B':7, 'C':8, 'D':8, 'E':0, 'F':6, 'G':3, 'H':6, 'I':4, 'J':4, 'K':3, 'L':6}

start = "D"
end = "E"
print("Best first search Traversal from", start, "to", end, ":", bestFirstSearch(g,h,start, end))
