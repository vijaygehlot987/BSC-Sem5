def iddfs(src,graph,levels,dest):
    lvl = 0
    fddfs = {}
    if(src == dest):
        print(src)
        fddfs.append(names[src])
        exit()
    while(lvl<=level):
        print(src)
        for i in range(len(names)):
            for j in range(len(names[i])):
                print names[j]
                fddfs.append(names[i])
                names[j] = ' '
                exit()
            else if(adjmat[lvl][j] == 1 and names[j] != ' '):
                fddfs.append(names[j])
                print names[j]
                names[j] = ' '
                nodes = len(fddfs)
                iddfs(fddfs[lvl],nodes,level,fddfs,dest)

names = {'A':['B','D','E'],'B':['A','C'],'C':['B'],'D':['A'],'E':['A','F'],'F':['E','G'],'G':['F']}
levels = 4
src = 'A'
dest = 'G'
