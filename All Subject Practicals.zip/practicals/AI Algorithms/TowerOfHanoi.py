def TowerOfHanoi(towers, n, noOfDisks):
    if n > 1:
        TowerOfHanoi(towers, n-1, noOfDisks)
    solve(towers, n, noOfDisks)
    print("Source : ", towers[0])
    print("Auxilary : ", towers[1])
    print("Destination : ", towers[2])
    print()
    if n > 1:
        TowerOfHanoi(towers, n-1, noOfDisks)
        
def solve(towers, n, noOfDisks):
    if noOfDisks % 2 != 0 :
        for i in range(len(towers)):
            if not towers[i]:
                continue
            if towers[i][len(towers[i])-1] == n:
                popLocation = i
                break
        if n % 2 == 0:
            pushLocation = (popLocation + 1) % 3
            towers[pushLocation].append(towers[popLocation].pop())
        else :
            pushLocation = (popLocation + 2) % 3
            towers[pushLocation].append(towers[popLocation].pop())
    else:
        for i in range(len(towers)):
            if not towers[i]:
                continue
            if towers[i][len(towers[i])-1] == n:
                popLocation = i
                break
        if n % 2 == 0:
            pushLocation = (popLocation + 2) % 3
            towers[pushLocation].append(towers[popLocation].pop())
        else :
            pushLocation = (popLocation + 1) % 3
            towers[pushLocation].append(towers[popLocation].pop())       



towers = [[6,5,4,3,2,1],[],[]]
TowerOfHanoi(towers, 6, 6)
