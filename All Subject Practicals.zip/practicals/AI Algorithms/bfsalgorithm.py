graph={
    "S" : ["A", "B", "C"],
    "A" : ["B", "D", "S"],
    "B" : ["A", "S", "D", "H"],
    "C" : ["S", "L"],
    "D" : ["A", "F", "B"],
    "E" : ["G", "K"],
    "F" : ["D", "H"],
    "G" : ["H", "E"],
    "H" : ["B", "F", "G"],
    "I" : ["L", "K"],
    "J" : ["L", "K"],
    "K" : ["I", "J", "E"],
    "L" : ["C", "I", "J"]
    }
visited=[]
queue=[]
def bfs(graph,src,dest):
    if src not in visited:
        visited.append(src)
    if src in queue:
        queue.remove(src)
    for i in graph[src]:
        if i not in queue and i not in visited:
            queue.append(i)
    for i in queue:
        if dest not in visited:
            src=i
            bfs(graph,src,dest)
        else:
            break
bfs(graph,"A","F")
print(visited)
        
    
