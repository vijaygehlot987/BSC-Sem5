def bfs(pos,node,dest):
        flag=0
        fbfs=[]
        for i in range(node):
                #print(i)
                #print(pos)
                first=0
                if(names[pos]!=' '):
                        print(names[pos])
                        names[pos]=' '
                for j in range(node):
                        if(names[j]==dest and adjmat[pos][j]==1):
                                print(names[j])
                                fbfs.append(names[j])
                                names[j]=' '
                                flag=1
                                break
                        if(adjmat[pos][j]==1 and names[j]!=' ' and first==0):
                                print(names[j])
                                fbfs.append(j)
                                newpos=fbfs[i]
                                names[j]=' '
                                first=1
                        if(adjmat[pos][j]==1 and names[j]!=' '):
                                print(names[j])
                                fbfs.append(j)
                                names[j]=' '
                pos=newpos
                if flag==1:
                        break

def dfs(pos,node,dest):
        fbfs=[]
        if names[pos]==dest:
                print(names[pos])
                names[pos]=' '
                exit()
        else:
                print(names[pos])
                names[pos]=' '
                for i in range(node):
                        if(adjmat[pos][i]==1 and names[i]!=' '):
                                dfs(i,node,dest)
                

names = ['A','B','C','D','F','E','G']
node = 7
adjmat = [[0,1,0,1,0,0,1],
          [1,0,1,0,0,0,0],
          [0,1,0,1,0,0,0],
          [1,0,1,0,1,1,1],
          [0,0,0,1,0,1,0],
          [0,0,0,1,1,0,0],
          [1,0,0,1,0,0,0]
         ]
src='F'
dest='A'
pos=names.index(src)
#bfs(pos,node,dest)
dfs(pos,node,dest)
