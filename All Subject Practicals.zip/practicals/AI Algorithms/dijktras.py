"""
Terms :
pq = processing queue (i.e elements stilled not processed completely). Elements - [weight, presentNode, viaWhichNode]
p = processing element (i.e element currently being processed)
processed = elements done being processed
trace = backtracing elements
"""
import heapq
def dijktras(graph, start, end):
    p = [0, start, start]
    pq = [[0, start, start]]
    processed = []
    done = []
    while pq :
        heapq.heapify(pq)                                   #Priority Queue is used in order to maintain the Priority
        p = pq.pop(0)
        for node, weight in graph[p[1]]:                    #Processes the current element (i.e p)
            if node not in done:
                pos = None
                found = False
                for i in range(len(pq)):                    #Searches for the adj Node to be modified
                    if pq[i][1] == node :
                        found = True
                        pos = i
                        break
                if found:
                    if p[0] + weight < pq[pos][0]:          #Dijktras Relaxation
                        pq[pos][0] = p[0] + weight
                        pq[pos][2] = p[1]
                else:
                    pq.append([p[0] + weight, node, p[1]])  #If search for adj Node fails, appends the adj node to pq
        done.append(p[1])
        processed.append(p)
    print(processed)
    path = []
    trace = end
    for i in range(len(processed) - 1, -1, -1):
        if trace == processed[i][1]:
            path.insert(0, processed[i][1])
            trace = processed[i][2]
    return path
    
##Input 1
##g = {
##    "A" : [["B", 6], ["F", 3]],
##    "B" : [["A", 6], ["C", 3], ["D", 2]],
##    "C" : [["B", 3], ["D", 1], ["E", 5]],
##    "D" : [["B", 2], ["C", 1], ["E", 8]],
##    "E" : [["C", 5], ["D", 8], ["I", 5], ["J", 5]],
##    "F" : [["A", 3], ["G", 1], ["H", 7]],
##    "G" : [["F", 1], ["I", 3]],
##    "H" : [["F", 7], ["I", 2]],
##    "I" : [["E", 5], ["G", 3], ["H", 2], ["J", 3]],
##    "J" : [["E", 5], ["I", 3]]
##    }

##Input 2
g = {
    "S": [["A", 7], ["B", 2], ["C", 3]],
    "A" : [["B", 3], ["D", 4], ["S", 7]],
    "B" : [["A", 3], ["S", 2], ["D", 4], ["H", 1]],
    "C" : [["S", 3], ["L", 2]],
    "D" : [["B", 4], ["A", 4], ["F", 5]],
    "E" : [["G", 2], ["K", 5]],
    "F" : [["D", 5], ["H", 3]],
    "G" : [["H", 2], ["E", 2]],
    "H" : [["B", 1], ["F", 3], ["G", 2]],
    "I" : [["L", 4], ["K", 4]],
    "J" : [["L", 4], ["K", 4]],
    "K" : [["I", 4], ["J", 4]],
    "L" : [["C", 2], ["I", 4], ["J", 4]]
    }

start = "S"
end = "E"
print("Path from ", start, "to", end, ":",dijktras(g, start, end))
