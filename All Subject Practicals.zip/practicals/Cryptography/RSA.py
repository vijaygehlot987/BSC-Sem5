"""
How RSA works :
--> Select 2 prime Numbers p and q
--> Calculate n = p * q
--> Calculate EulerTotient i.e phi(n) = (p-1)*(q-1)
--> Select e such that GCD(e, phi(n)) = 1 ......0 < e < phi(n)
--> Select d such that (d * e) mod phi(n) = 1 OR d*e = 1(mod phi(n))
--> Public Key = {e, n}
--> Private Key = {d, n}
"""

import math
import random

def RSA(msg):
    p = generatePrime()                                     #Generating random Primes : p & q
    q = generatePrime()
    n = p*q
    phi = (p-1) * (q-1)                                     #phi(n)
    
    while True:
        e = random.randint(2, phi)                          #Generating appropiate e and d
        gcdVal, d = GCD(phi,e)
        if gcdVal == 1 : break
    d = d % phi
    
    print("Public Key {n,e} :",n,e)
    print("Private Key {n,d} :",n,d)
    print("d*e mod phi :", d * e % phi)
    
##    code = []                                               #Encryption
##    for i in msg:
##        code.append(pow((ord(i) - 97), e) % n)
##    print("Encryption :", code)
##    
##    m = ""
##    for i in code:                                          #Decryption
##        m += chr(pow(i, d) % n + 97)
##    print("Decryption :" ,m)

        
def isPrime(n):                                             # PrimeChecker
    if n == 1: return False
    elif n == 2 : return True
    elif n % 2 == 0 : return False
    else:
        for i in range(3, math.floor(n**0.5) + 1, 2):
            if n % i == 0:
                return False
        return True

def generatePrime(lb = 100000000, ub = 1000000000):       # PrimeGenerator 
    while True:
        num = random.randint(lb, ub)
        if isPrime(num) : return num

def GCD(a, b):                                              # GCD and d value Calculator
    t1 = 0
    t2 = 1
    while b > 0:
        q = a // b
        r = a - q*b
        a = b
        b = r
        t = t1 - t2*q
        t1 = t2
        t2 = t
    return (a, t1)

def power(a, x):
    i = 1
    temp = a
    while True:
        if i*2 <= x:
            temp *= temp
            i *= 2
            print(i)
            print(temp)
        else:
            break
    if x % i != 0:
        temp *= a**(x%i)
        
    return temp
        

##msg = "prakhar"
##print("Message :", msg)
##RSA(msg)
print(power(3, 26431202092983151))

##print(GCD(23,100))
