import random
def VernumCipher(msg):
	code = ""
	for i in range(len(msg)//26):
		code += encrypt(msg[26*i : 26*(i+1)])
	if len(msg) % 26 != 0:
		code += encrypt(msg[-1*len(msg) % 26:])
	return code

def encrypt(msg):
	code = ""
	keys = [i for i in range(26)]
	random.shuffle(keys)
	# print(keys)
	for i in range(len(msg)):
		code += chr((ord(msg[i]) + keys[i] - 97) % 26 + 97)
	return code

msg = "iamahackerandilovetoexploit"
print("Message :",msg)
print("CipherText :",VernumCipher(msg))
