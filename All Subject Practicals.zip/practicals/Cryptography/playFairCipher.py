#playFairCipher is our Main algorithm
#This cipher is only intended to work with lowercase letters
def playFairCipher(msg, key):
    keyset = []
    key = key.replace(" ","")       #Removing the blank spaces
    
    for i in key :                  #Makes the table according to the message
        if i not in keyset:
            if i != "j":
                keyset.append(i)
    for i in range(97, 123):        #Takes remaining character which were not there in the cipherKey
        if chr(i) not in keyset:
            if chr(i) != "j" :      #rejecting j, treating j as i (Rule)
                keyset.append(chr(i))

    keyMatrix = [keyset[i:i+5] for i in range(0,25,5)]      #Makes a 5x5 table of where j is not used
    print("Encryption table :")
    for row in keyMatrix:           #Prints the 5x5 cipherKey table
        for e in row:
            print(e, end = "\t")
        print()

    msg = msg.replace(" ", "")      #Removing blankspaces
    msg = msg.replace("j", "i")     #replacing j's with i's because j is treated as i and j is not present in the table
    
    count = 0
    code = ""
    noOfX = 0
    while count <= (len(msg) - 1):          #Loops until the msg ends;
        if count == len(msg) - 1:       #Prevents index out of range
            break
        first = msg[count]              #Taking 1st character at a time
        second = msg[count+1]           #Taking 2nd Character at a time
        code, count, noOfX = encrypt(first, second, code, keyMatrix, count, noOfX)          #Returns the tuple and multiple assignment happens
            
    if (len(msg) + noOfX) % 2 != 0:     #checks no of X's used in cipher text, which increases the length of cipherText; If incase last character is left to be Decrypted
        elements = [msg[len(msg) - 1], "x"]
        code = encrypt(msg[len(msg) - 1], "x", code, keyMatrix)         #Returns only cipher text, count and noOfX is not needed in contrary to previous use of Encrypt
    return code

#encrypt function helps in reducing the redundancy of the code
def encrypt(first, second, code, keyMatrix, count = None, noOfX = None):
    if first == second:
        code += first + "x"
        if count != None:
            count += 1
        if noOfX != None:
            noOfX += 1
    else:
        elements = [first, second]
        indexes = []
        for i in elements:
            for j in range(5):
                for k in range(5):
                    if i == keyMatrix[j][k]:
                        indexes.append([j, k])
##        print(indexes)
        if indexes[0][0] == indexes[1][0]:                      #Checks wheather they are is same row
            indexes[0][1] = (indexes[0][1] + 1) % 5             #increases the colomn index
            indexes[1][1] = (indexes[1][1] + 1) % 5             #increases the colomn index
##            print("New",indexes)
            print()
            code += keyMatrix[indexes[0][0]][indexes[0][1]]     #Adding the produced cipherText
            code += keyMatrix[indexes[1][0]][indexes[1][1]]
            
        elif indexes[0][1] == indexes[1][1]:                    #Checks wheather they are is same colomns
            indexes[0][0] = (indexes[0][0] + 1) % 5             #increases the row index
            indexes[1][0] = (indexes[1][0] + 1) % 5             #increases the row index
##            print("New",indexes)
            code += keyMatrix[indexes[0][0]][indexes[0][1]]     #Adding the produced cipherText
            code += keyMatrix[indexes[1][0]][indexes[1][1]]
            
        else:
##            print(indexes)
            code += keyMatrix[indexes[0][0]][indexes[1][1]]     #Adding the intersection of the first and second letter w.r.t to first's row
            code += keyMatrix[indexes[1][0]][indexes[0][1]]     #Adding the intersection of the first and second letter w.r.t to second's row
        if count != None:
            count += 2
    if count != None and noOfX != None:
            return (code, count, noOfX)
    else:
        return code
    
msg = "balloon"
key = "monarchy"
print("Message : ", msg)
print("Key : ", key)
print("Encryption : ",playFairCipher(msg, key))
