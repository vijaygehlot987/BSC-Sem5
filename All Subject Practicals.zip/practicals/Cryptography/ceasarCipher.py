# Implementation of Ceasar Cipher

def ceasarCipher(string, key):
    lower = [chr(i) for i in range(97, 123)]
    upper = [chr(i) for i in range(65, 91)]
    
    code = ""
    for i in string:
        if i.islower():
            code += lower[(ord(i) - 97 + key) % len(lower)]
        elif i.isupper():
            code += upper[(ord(i) - 65 + key) % len(upper)]
        else:
            code += i
    return code
x = "middle-Outz"
print(ceasarCipher(x, 2))
